<template>
  <div class="home-container">
    <div class="home-topbar">
      <h1 class="home-text"><span>choke&apos;s terrible site</span></h1>
    </div>
    <div class="home-container1">
      <img
        alt="Github Logo"
        src="/playground_assets/%5Bobject%20object%5D-370r.svg"
        class="home-image"
      />
      <a
        href="https://github.com/choke-dev"
        target="_blank"
        rel="noreferrer noopener"
        class="home-link"
      >
        <span class="home-text2">Gith</span>
        <span class="home-text3"></span>
        <span class="home-text4">ub</span>
      </a>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Home',
  head: {
    title: 'Positive Distant Chicken',
    meta: [
      {
        property: 'og:title',
        content: 'Positive Distant Chicken',
      },
    ],
  },
}
</script>

<style scoped>
.home-container {
  width: 100%;
  display: flex;
  overflow: auto;
  min-height: 100vh;
  align-items: flex-start;
  flex-direction: column;
  justify-content: center;
  background-color: #272626;
}
.home-topbar {
  top: 7px;
  left: 0px;
  right: 0px;
  width: 1828px;
  height: 92px;
  margin: auto;
  display: flex;
  position: absolute;
  align-self: center;
  transition: 0.3s;
  align-items: center;
  padding-top: 0px;
  border-color: #313131;
  border-width: var(--dl-size-size-xsmall);
  border-radius: 16px;
  padding-bottom: 0px;
  justify-content: center;
  background-color: #313131;
}
.home-topbar:hover {
  border-color: #3D3D3D;
  background-color: #3d3d3d;
}
.home-text {
  color: #ffffff;
  width: 695px;
  height: 54px;
  font-size: 3em;
  align-self: center;
  font-style: normal;
  text-align: center;
  font-family: VT323;
  font-weight: 400;
  border-radius: var(--dl-radius-radius-radius4);
  text-transform: lowercase;
}
.home-container1 {
  top: 154px;
  left: 0px;
  right: 0px;
  width: 500px;
  height: 500px;
  margin: auto;
  display: flex;
  position: absolute;
  align-items: flex-start;
  justify-content: flex-start;
}
.home-image {
  width: 78px;
  height: 85px;
  object-fit: cover;
  margin-bottom: var(--dl-space-space-twounits);
}
.home-link {
  color: #ffffff;
  font-size: 32px;
  align-self: flex-start;
  text-align: center;
  font-family: VT323;
  padding-top: var(--dl-space-space-unit);
  padding-left: var(--dl-space-space-unit);
  text-transform: lowercase;
}
.home-text2 {
  font-family: VT323;
}
.home-text3 {
  text-align: center;
  font-family: VT323;
}
.home-text4 {
  font-family: VT323;
}
</style>
