export default {
  css: [`~/style.css`]
};
